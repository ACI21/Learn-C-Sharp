class EstudianteNecesidadesEducativasEspeciales :Estudiante
{
    public  EstudianteNecesidadesEducativasEspeciales( string nombre):base(nombre)
    {
        /*
         * Mal:
         * this.nombre=nombre; 
         * no hace falta porque el string nombre de la clase estudiante es privado, readonly y no tiene setNombre(). 
         * No se puede modificar
        */
        
        // Mejor en blanco

        
    }

    // Como el Estudiante.Responde() está marcado como virtual, ahora puedes hacerlo override
    // Es importante hacerlo override ya que asi declaras que vas a sobreescribir la otra función
    // Y no vas a escribir otra distinta.
    public override string  Responde ()
    {
        string respuesta2="Estoy trabajando con el apoyo de un educador especial";
        return respuesta2;
        
    }


}