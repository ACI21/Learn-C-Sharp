
class Escuela
{
    /* 
     * Ausencia de variables estudiantes y orientadores.
     * En este caso deberían haber sido listas para agregar 
     * indefinidos estudiantes y orientadores
    */
    // Correción:
    List<Estudiante> estudiantes;
    List<Orientador> orientadores;

    /*
     * No del todo mal:
     * public Escuela(Estudiante estudiante,Orientador orientador)
     * {
     *     this.estudiante=estudiante;
     *     this.orientador=orientador;
     * } 
     * 
     * No ibas mal desencaminada pero en este caso era el constructor
     * en vacio, no necesitamos de parametros para hacer estudiantes 
     * u orientadores.
    */
    //Correcion
    public Escuela()
    {
        this.estudiantes = new List<Estudiante>();
        this.orientadores = new List<Orientador>();
    }

    //Falta el retornable de tipo Escuela
    public Escuela Contrata(Orientador orientador)
    {
        // Validar que el orientador no sea nulo
        if (orientador == null)
        {
            throw new EscuelaException("El orientador no puede ser nulo.");
        }

        // Agregar el orientador a la lista de orientadores
        this.orientadores.Add(orientador);

        // Devolver la escuela
        return this;
    }

    //Falta el retornable de tipo Escuela
    public Escuela Matricula(Estudiante estudiante)
    {
        // Validar que el estudiante no sea nulo
        if (estudiante == null)
        {
            throw new EscuelaException("El estudiante no puede ser nulo.");
        }

        // Agregar el estudiante a la lista de estudiantes
        this.estudiantes.Add(estudiante);

        // Devolver la escuela
        return this;
    }

    //No es de tipo Escuela, es de tipo Orientador
    //Falta el retornable de tipo Orientador
    //Random incompleto
    //No hace falta parametros, la idea es devolver un orientador
    private Orientador ObtenerOrientadorAleatorio()
    {

        /*
         * Mal:
         * orientador = new Random;
         * 
         * Está incompleto y no se puede hacer un random de esta forma
        */
        //Correcion:
        if (orientadores.Count == 0)
        {
            throw new EscuelaException("No hay orientadores disponibles. Contrata orientadores antes de orientar estudiantes.");
        }
        else
        {
            // Se saca uno aleatorio de entre los que existen
            var orientadorSeleccionado = orientadores[new Random().Next(orientadores.Count)];
            return orientadorSeleccionado;
        }
    }

    /*
     * Faltaba por implementar todo, lo único que hace esto es coger el listado
     * de estudiantes, recorrerlos y en cada iteración escogemos a un 
     * orientador aleatorio 
    */
    public void OrientarEstudiantes()
    {
        for (int i = 0; i < estudiantes.Count; i++)
        {
            var orientadorRandom = ObtenerOrientadorAleatorio();
            orientadorRandom.Orienta(estudiantes[i]);
        }
    }
}