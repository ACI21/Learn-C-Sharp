using System.Runtime.Serialization;

// Faltaba por crear esta clase entera
class EscuelaException : Exception
{
    public EscuelaException()
    {
    }

    public EscuelaException(string? message) : base(message)
    {
    }
}