﻿using System;

class Estudiante
{
    private readonly String nombre;

    public Estudiante(string nombre){
        this.nombre=nombre;
    }
    public String GetNombre(){
        return nombre;
    }

    // Había que marcarlo como virtual para luego poder hacerle override
    public virtual String Responde(){
        /* 
         * Mal: 
         * string respuesta; //Esto está bien
         * Console.WriteLine("Estoy estudaindo"); //También está bien
         * respuesta= Console.ReadLine(); //¿Por qué le pides datos? Debe ser siempre la misma respuesta
         * return respuesta;
        */

        //Correcion
        string respuesta = "Estoy estudiando";
        return respuesta; //Mejor respuesta
    }
}