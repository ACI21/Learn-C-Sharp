using System.Dynamic;
using System.Reflection.Metadata.Ecma335;
using System.Runtime;

abstract class Orientador
{

    private readonly string nombre;

    // Se te ha duplicado la variable nombre y no existe ninguna clase Nombre
    // private Nombre nombre;

    protected Orientador(string nombre)
    {
        /*
         * Mal:
         * Setnombre(nombre); 
         * 
         * Intentas llamar a una función que no existe en esta clase, 
         * además, estás definiendo al constructor, tan fácil como...
        */

        // Correción
        this.nombre = nombre;

    }
    public string Getnombre()
    {
        return nombre;
    }
    public void Orienta(Estudiante estudiante)
    {
        /*
         * Mal: 
         * this.estudiante = estudiante ;
         * 
         * Esto se debe a que no existe ninguna variable llamada estudiante en la clase actual.
        */

       //Correcion:
       Console.WriteLine($"Orientado a {estudiante.GetNombre()} por parte de {this.Getnombre()} ------");
       Console.WriteLine($"\n[{this.Getnombre()}]: Hola {estudiante.GetNombre()}, soy tu orientador/a {this.Getnombre()} ¿Cómo estás hoy?");
       Console.WriteLine($"[{this.Getnombre()}]: {this.GetPregunta()}");
       Console.WriteLine($"[{estudiante.GetNombre()}]: {estudiante.Responde()}");
       Console.WriteLine($"[{this.Getnombre()}]: {this.GetReplica()}");
       Console.WriteLine($"[{this.Getnombre()}]: Mi consejo para ti es {this.GetOrientacion(estudiante)}\n");
    }

    /*
     * Mal: 
     * protected string GetOrientacion()
     * {
     *     return " ";
     * }
     * Falta que sea abstract, por lo que no debe tener ni cuerpo.
    */
    //Correcion:
    public abstract string GetOrientacion(Estudiante estudiante);

    /*
     * Mal: 
     * protected string GetPregunta()
     * {
     *  return pregunta;
     * }
     * Esto se debe a que no existe ninguna variable llamada pregunta en la funcion actual.
     * Además, falta que sea abstract, por lo que no debe tener ni cuerpo.
    */
    //Correcion:
    protected abstract string GetPregunta();

    /*
     * Mal: 
     * protected string GetReplica()
     * {
     *  return replica;
     * }
     * Esto se debe a que no existe ninguna variable llamada replica en la funcion actual.
     * Además, falta que sea abstract, por lo que no debe tener ni cuerpo.

    */
    //Correcion
    protected abstract string GetReplica();

}