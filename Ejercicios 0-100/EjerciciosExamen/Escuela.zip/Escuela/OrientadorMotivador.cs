class OrientadorMotivador : Orientador
{
    public OrientadorMotivador(string nombre) : base(nombre) 
    {
    }

    /*
     * Mal:
     * protected string GetOrientadorMotivador(Estudiante estudiante)
     * {
     *     return;
     * }
     * 
     * Esta función no existe en el esquema. Pero te refieres a esto: 
    */

    // Correción:
    public override string GetOrientacion(Estudiante estudiante)
    {
        // Se define una variable para almacenar la orientación del estudiante
        string orientacion = "";

        // Se comprueba el tipo de estudiante
        if (estudiante is EstudianteAltasCapacidades)
        {
            // Se obtiene la orientación del estudiante de altas capacidades
            orientacion = "Explorar proyectos más desafiantes.";
        }
        else if (estudiante is EstudianteApoyoIdioma)
        {
            // Se obtiene la orientación del estudiante de apoyo idioma
            orientacion = "Sumergirte en prácticas diarias para mejorar tus habilidades lingüísticas.";
        }
        else if (estudiante is EstudianteDisruptivo)
        {
            // Se obtiene la orientación del estudiante disruptivo
            orientacion = "Transformar tus deasfios en oportunidades de crecimiento personal.";
        }
        else if (estudiante is EstudianteNecesidadesEducativasEspeciales)
        {
            // Se obtiene la orientación del estudiante de necesidades educativas especiales
            orientacion = "Superar cualquier obstáculo educativo que encuentres.";
        }
        else
        {
            // Se lanza una excepción si el tipo de estudiante no es válido
            throw new ArgumentException("Tipo de estudiante no válido");
        }

        return orientacion;
    }


    // Falta poner override
    protected override String GetPregunta()
    {
        /*
         * Mal:
         * this.pregunta = new Pregunta("Cuentame, que te motiva a seguir aprendiendo?");
         * return Pregunta;
         * 
         * ¿this.pregunta? No existe una variable así en la clase, de hecho no hay variables
         * Aunque exisitiese, seria de tipo string y no de tipo Pregunta() como si tuviese clase y constructor.
         * El return está mal porque 1. devuelve Pregunta con la 'p' en mayus y 2. La variable sigue sin existir
        */

        //Corrección:
        string pregunta = "Cuéntame, ¿qué te motiva a seguir aprendiendo?";
        return pregunta;
    }

    // Falta poner override
    protected override String GetReplica()
    {
        /*
         * Mal:
         * switch (estudiante)
         * {
         *     case '1':
         *         estudiante == estudianteAltasCapacidades;
         *         Console.WriteLine("Explorar proyectos mas desafiantes");
         *         break;
         *     case '2':
         *         estudiante == estudianteNecesidadesEducativasEspeciales;
         *         Console.WriteLine("superar cualquier obstaculo educativo que encuentres");
         *         break;
         *     case '3':
         *         estudiante == estudianteApoyoIdioma;
         *         Console.WriteLine("sumergirte en practicas diarais para superar tus habilidades");
         *         break;
         *     case '4':
         *         estudiante == estudianteDisruptivo;
         *         Console.WriteLine("transformar tus desafios en oportunidades de crecimientro");
         *         break;
         *     default:
         *         break;
         * } 
         * Console.WriteLine("Hay algo que te este preocupando en la escuela" + respuesta);
         * 
         * 
         * Falta la variable estudiante y no se requiere como parámetro
         * Falta la estructura del if dentro del switch
         * El switch no puede clasificar un objeto, debe ser algo más concreto
         * Y falta el return y la variable respuesta nunca se le asigna valor.
        */

        //Correción:
        string respuesta = $"Entiendo, es genial que tengas esa motivación.";
        return respuesta;
    }
}