namespace Ejercicios_Examen;

public class AjedrezException : Exception
{
    public AjedrezException() : base()
    {
    }

    public AjedrezException(string message) : base(message)
    {
    }
}
