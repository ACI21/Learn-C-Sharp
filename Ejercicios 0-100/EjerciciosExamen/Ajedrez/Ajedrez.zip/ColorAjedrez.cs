namespace Ejercicios_Examen;

public enum ColorAjedrez
{
   Blanco, Negro
}