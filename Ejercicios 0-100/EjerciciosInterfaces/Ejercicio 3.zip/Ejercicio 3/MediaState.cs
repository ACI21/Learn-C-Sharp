using System;

public enum MediaState {
	Stopped,
	Paused,
	Playing,
	Hearing
}
