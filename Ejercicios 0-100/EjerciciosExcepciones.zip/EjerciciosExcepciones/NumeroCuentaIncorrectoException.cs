class NumeroCuentaIncorrectoException : Exception
{
    public NumeroCuentaIncorrectoException() : base()
    {
    }

    public NumeroCuentaIncorrectoException(string message) : base(message)
    {
    }
}
