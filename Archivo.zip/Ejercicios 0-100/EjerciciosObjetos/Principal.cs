using System.ComponentModel.DataAnnotations.Schema;

namespace Ejercicios_0_100;

public class Principal
{
    public static void Main(string[] args)
    {
        Personaje personaje1 = new Personaje("Dora", 1000, "Mago");
        personaje1.Saludar();
        personaje1.Atacar();

        string nombre = personaje1.getNombre(); // getter
        personaje1.setNombre("Swiper"); // setter

        Personaje personaje2 = new Personaje("Dora", 1000, "Mago");

        personaje1.Equals(personaje2); // true, son iguales
    }
}